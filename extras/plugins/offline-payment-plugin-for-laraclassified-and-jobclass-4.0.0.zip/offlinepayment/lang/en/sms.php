<?php

return [
	
	// payment_sent
	'payment_sent_content' => ':appName - We have received your offline payment request for the ad ":title". We will wait to receive your payment to process your request. Thank you!',

];
